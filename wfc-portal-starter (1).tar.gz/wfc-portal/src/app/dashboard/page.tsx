"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";

const navItems = [
  { name: "Dashboard", href: "/dashboard", icon: "⊞" },
  { name: "Taarifa zangu", href: "/dashboard/profile", icon: "👤" },
  { name: "Michango", href: "/dashboard/contributions", icon: "💰" },
  { name: "Matukio", href: "/dashboard/events", icon: "📅" },
  { name: "Matangazo", href: "/dashboard/announcements", icon: "📢" },
];

export default function DashboardPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-white border-r border-gray-200 transform transition-transform duration-200 lg:static lg:translate-x-0 ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}`}>
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="p-6 border-b border-gray-100 flex flex-col items-center">
            <Image
              src="/wfc-logo.jpg"
              alt="WFC Logo"
              width={90}
              height={90}
              className="rounded-full"
            />
            <p className="mt-2 text-xs text-orange-600 font-medium text-center">
              Stand up · It's not over
            </p>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-4 space-y-1">
            {navItems.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-700 hover:bg-orange-50 hover:text-orange-600 transition-colors font-medium"
              >
                <span className="text-lg">{item.icon}</span>
                {item.name}
              </Link>
            ))}
          </nav>

          {/* Logout */}
          <div className="p-4 border-t border-gray-100">
            <Link
              href="/"
              className="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-600 hover:bg-gray-100 transition-colors"
            >
              <span>🚪</span>
              Toka nje
            </Link>
          </div>
        </div>
      </aside>

      {/* Overlay for mobile */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/20 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Bar */}
        <header className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden p-2 rounded-lg hover:bg-gray-100"
          >
            ☰
          </button>
          <div className="flex-1" />
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center text-orange-600 font-semibold">
              WM
            </div>
            <div className="hidden sm:block">
              <p className="text-sm font-medium">Mwanachama</p>
              <p className="text-xs text-gray-500">WFC-0001</p>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <main className="flex-1 p-6">
          <div className="max-w-6xl mx-auto">
            <h1 className="text-2xl font-bold text-gray-900 mb-1">Karibu kwenye WFC Portal</h1>
            <p className="text-gray-600 mb-8">Umoja wa Wachagga, Nguvu ya Familia</p>

            {/* Member Info Card */}
            <div className="bg-white rounded-2xl border border-gray-200 p-6 mb-6 shadow-sm">
              <h2 className="text-lg font-semibold mb-4">Taarifa za Mwanachama</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Jina</p>
                  <p className="font-medium">Mwanachama wa WFC</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">WFC ID</p>
                  <p className="font-medium text-orange-600">WFC-0001</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Kanda</p>
                  <p className="font-medium">Dar es Salaam</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Hali</p>
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-700">
                    Hai
                  </span>
                </div>
              </div>
            </div>

            {/* Payment Summary */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
                <p className="text-sm text-gray-500 mb-1">Jumla aliyolipa</p>
                <p className="text-3xl font-bold text-orange-600">TSh 0</p>
                <p className="text-xs text-green-600 mt-2">● Imelipwa</p>
              </div>
              <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
                <p className="text-sm text-gray-500 mb-1">Deni lake</p>
                <p className="text-3xl font-bold text-gray-900">TSh 0</p>
                <p className="text-xs text-green-600 mt-2">● Hakuna deni</p>
              </div>
            </div>

            {/* Announcements */}
            <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
              <h2 className="text-lg font-semibold mb-4">Matangazo ya Hivi Karibuni</h2>
              <div className="space-y-4">
                <div className="flex items-start gap-4 p-4 bg-orange-50 rounded-xl">
                  <span className="text-orange-500 text-xl">📢</span>
                  <div>
                    <p className="font-medium">Karibu kwenye mfumo mpya wa WFC</p>
                    <p className="text-sm text-gray-600 mt-1">
                      Tunakaribisha wanachama wote kwenye portal rasmi ya kidijitali. Stand up, it's not over.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
